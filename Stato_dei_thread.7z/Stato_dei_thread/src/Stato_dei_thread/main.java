package Stato_dei_thread;
import java.util.Scanner;
import java.util.Random;

public class main {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
			
		Scanner scanner = new Scanner(System.in);
		Random random = new Random();
		
		int f;
		
		System.out.println("Quanti thread vuoi?");
		int t = scanner.nextInt();
		
		System.out.println("fino a quanto devono contare?");
		int n = scanner.nextInt();
		
		int x = random.nextInt(n+1);
		
		for(int i=0; i<t; i++) {
			contatore cont = new contatore();
			cont.setN(x);
			Thread thread = new Thread(cont,"thread"+(i+1));
			thread.start();
			//f = contatore.getF();
		}


		
	}

}
