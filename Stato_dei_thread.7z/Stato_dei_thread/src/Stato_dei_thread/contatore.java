package Stato_dei_thread;

public class contatore implements Runnable {

	
		private int n;
		private int f;


		contatore(){
			n = 0;
		}

		public void setN(int n) {
			this.n = n;
		}
		
		public int getF() {
			return f;
		}
		
		
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		for(int i=0; i<n; i++) {
			f = i;
			
			System.out.println(Thread.currentThread().getName()+" Ho contato");
			
			try {
				Thread.currentThread().sleep(120);
			}catch (Exception e) {};
			
			if(i==n-1) {
			System.out.println(Thread.currentThread().getName()+" Completato");

			}
			
			
			
			
		}

	}





}
